# Image-inpainting-with-OpenCV-and-Python



We all know there is always some pictures we have in our home which has some strokes, some black spot, any other distrubation on it. The restoring the complete clean image means wihout any spot is called image inpainting. The technique behind of image inpainting is we can't simply repalce the black spot to white spot so replace thoes black spot/bad marks with its neighbourhood pixel so its looks like neighbourhood and image become clean.

For run this project open the command prompt and go to the location where this project located and Run the command "python project1.py".
You will see the new tab open look like below image.
![image](https://user-images.githubusercontent.com/44130329/126040546-b3a2d34e-cadc-4ac0-a80e-44eb5c7ce557.png)

Select the image and mask image and click on inpaint then you will see the output as a image without bad spot.
![image](https://user-images.githubusercontent.com/44130329/126040592-47eb6734-9b30-4cff-9ebb-6c7a8cf0d979.png)
![image](https://user-images.githubusercontent.com/44130329/126040598-cd338247-b9bf-4cf6-a076-dc54a0e5a467.png)



import tkinter as Tk
from tkinter import *

root =Tk()
root.geometry("1240x700")
f1=Frame(root,bg="blue")
f1.pack(fill=BOTH,expand=True)


root.mainloop()